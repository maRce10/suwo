params <-
list(EVAL = FALSE)

## ----setup, eval = TRUE, echo = FALSE, message=FALSE----------------------------------------------

library(knitr)
library(suwo)

# Create custom printing method
.print_df <- function(x, highlight = NULL, ...) {
  kbl <- kableExtra::kable(
    head(as.data.frame(x)),
    align = "c",
    row.names = FALSE,
    format = "html",
    escape = FALSE
  )
  
  if (!is.null(highlight))
    kbl <- kableExtra::column_spec(
      kbl,
      column = which(names(x) %in% highlight),
      background = "#ccebff",
      bold = TRUE
    )
  
  kbl <- kableExtra::kable_styling(kbl, bootstrap_options = "striped", 
                                   font_size = 14)
  kbl <- kableExtra::scroll_box(kbl, width = "100%", height = "300px")
  
  asis_output(kbl)
}

# Register custom data frame print method
registerS3method("knit_print", "data.frame", .print_df)

# Global chunk options
knitr::opts_chunk$set(
  fig.width = 5,
  fig.height = 3.5,
  dpi = 70,
  comment = "",
  out.width = "80%",
  fig.align = "center",
  message = TRUE,
  warning = TRUE
)

options(width = 100, max.print = 100)

dir_tree <- function(path) {
  cat(gsub("\\[[0-9;]*[mK]", "", capture.output(fs::dir_tree(path))), 
      sep = "\n")
}

## ----eval = FALSE, echo = FALSE-------------------------------------------------------------------
# 
# #Install from CRAN:
# 
# # From CRAN would be
# install.packages("suwo")
# 
# #load package
# library(suwo)
# 
# 

## ----eval = FALSE---------------------------------------------------------------------------------
# 
# # install package
# remotes::install_github("maRce10/suwo")
# 
# #load packages
# library(suwo)
# 

## ----echo=TRUE------------------------------------------------------------------------------------
# Load suwo package
library(suwo)

## ----query_summary_table, echo=FALSE, results='asis', message=FALSE-------------------------------

library(knitr)
library(kableExtra)

metadata_list <-  vignette_metadata <- suwo:::vignette_metadata

Repository <- vapply(metadata_list, function(x)
  x[1, "repository"], character(1))

names(metadata_list) <- tolower(Repository)

Function <- c(
  gbif = "query_gbif",
  inaturalist = "query_inaturalist",
  `macaulay library` =  "query_macaulay",
  observation = "query_observation",
  wikiaves = "query_wikiaves",
  `xeno-canto` = "query_xenocanto"
)

Function <- Function[match(names(metadata_list), names(Function))]


file_types <- vapply(Function, function(x)
  paste(formals(get(x))$format, collapse = ", "), FUN.VALUE = character(1))
file_types <- gsub("c, ", "", file_types)
file_types[Function == "query_xenocanto"] <- "sound"

urls <- c(
  gbif = "https://www.gbif.org/",
  inaturalist = "https://www.inaturalist.org/",
  `macaulay library` =  "https://www.macaulaylibrary.org/",
  observation = "https://observation.org/",
  wikiaves = "https://www.wikiaves.com.br/",
  `xeno-canto` = "https://www.xeno-canto.org/"
)

urls <- urls[match(names(metadata_list), names(urls))]

token <- c(
  gbif = "No",
  inaturalist = "No",
  `macaulay library` =  "No",
  observation = "Yes",
  wikiaves = "No",
  `xeno-canto` = "Yes"
)

token <- token[match(names(metadata_list), names(token))]


tax_level <-  c(
  gbif = "Species",
  inaturalist = "Species",
  `macaulay library` =  "Species",
  observation = "Species",
  wikiaves = "Species",
  `xeno-canto` = "Species, subspecies, genus, family, group"
)

tax_level <- tax_level[match(names(metadata_list), names(tax_level))]

geo_cover <-  c(
  gbif = "Worldwide",
  inaturalist = "Worldwide",
  `macaulay library` =  "Worldwide",
  observation = "Worldwide",
  wikiaves = "Brazil",
  `xeno-canto` = "Worldwide"
)

geo_cover <- geo_cover[match(names(metadata_list), names(geo_cover))]

other <-  c(
  gbif = "Specify query by data base",
  inaturalist = NA,
  `macaulay library` =  "Interactive",
  observation = NA,
  wikiaves = NA,
  `xeno-canto` = "Specify query by taxonomy, geographic range and dates"
)

other <- other[match(names(metadata_list), names(other))]



colnames <- lapply(metadata_list, names)

colnames <- lapply(colnames, function(x)
  setdiff(x, suwo:::.format_query_output(only_basic_columns = TRUE)))

additional_data <- vapply(colnames, function(x)
  paste(x, collapse = ", "), FUN.VALUE = character(1))

additional_data <- additional_data[match(names(metadata_list), 
                                         names(additional_data))]

query_summary <- data.frame(
  Function = Function,
  Repository = Repository,
  `URL link` = urls,
  `File types` = file_types,
  `Requires api key` = token,
  `Taxonomic level` = tax_level,
  `Geographic coverage` = geo_cover,
  `Additional data` = additional_data,
  `Other features` = other,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

# remove duplicates
query_summary <- query_summary[!duplicated(query_summary$Repository), ]

query_summary <- query_summary[order(query_summary$Repository),]

query_summary$`URL link` <- kableExtra::cell_spec(query_summary$`URL link`,
                                                  "html",
                                                link = query_summary$`URL link`,
                                                  new_tab = TRUE)

query_summary$Function <- kableExtra::cell_spec(
  query_summary$Function,
  "html",
  link = paste0(
    "https://marce10.github.io/suwo/reference/",
    query_summary$Function,
    ".html"
  ),
  new_tab = TRUE
)

query_summary[, names(query_summary) != "Additional data"] |>
  kableExtra::kbl(
    caption = "Table 1: Summary of query functions.",
    format = "html",
    escape = FALSE,
    row.names = FALSE
  ) |>
  kableExtra::kable_styling(
    bootstrap_options = c("striped", "hover", "condensed", "responsive"),
    full_width = FALSE,
    position = "left"
  )


## ----eval = TRUE----------------------------------------------------------------------------------
# Load suwo package
library(suwo)

h_sarapiquensis <- query_inaturalist(species = "Heliconia sarapiquensis", 
                                     format = "image")

head(h_sarapiquensis, 4)

## ----eval = FALSE---------------------------------------------------------------------------------
# 
# h_harpyja <- query_wikiaves(species = "Harpia harpyja", format = "sound")
# 
# head(h_harpyja, 4)

## ----echo=FALSE-----------------------------------------------------------------------------------

subset(vignette_metadata$h_harpyja, 
       select = suwo:::.format_query_output(only_basic_columns = TRUE))


## ----eval = FALSE---------------------------------------------------------------------------------
# 
# p_lotor <- query_gbif(species = "Procyon lotor", format = "video")
# 
# head(p_lotor, 4)

## ----echo=FALSE-----------------------------------------------------------------------------------

subset(vignette_metadata$p_lotor, 
       select = suwo:::.format_query_output(only_basic_columns = TRUE))


## ----echo=FALSE, results='asis', message=FALSE----------------------------------------------------

query_summary[, c("Function", "Additional data")] |>
  kableExtra::kbl(
    caption = "Table 2: Additional metadata per query function.",
    format = "html",
    escape = FALSE,
    row.names = FALSE
  ) |>
  kableExtra::kable_styling(
    bootstrap_options = c("striped", "hover", "condensed", "responsive"),
    full_width = FALSE,
    position = "left"
  )


## ----eval = FALSE---------------------------------------------------------------------------------
# p_striigularis <- query_macaulay(species = "Phaethornis striigularis",
#                                  format = "video")

## ----eval=FALSE-----------------------------------------------------------------------------------
# head(p_striigularis, 4)

## ----echo=FALSE-----------------------------------------------------------------------------------

subset(vignette_metadata$p_striigularis, 
       select = suwo:::.format_query_output(only_basic_columns = TRUE))


## ----eval = FALSE---------------------------------------------------------------------------------
# # test a query with more than 10000 results paging by date
# cal_cos <- query_macaulay(
#   species = "Calypte costae",
#   format = "image",
#   path = tempdir(),
#   dates = c(1976, 2019, 2022, 2024, 2025, 2026)
# )

## ----eval = FALSE---------------------------------------------------------------------------------
# 
# # replace "YOUR_XC_API_KEY" with your key
# t_tricolor <- query_xenocanto(species = "Thyroptera tricolor",
#                               api_key = "YOUR_XC_API_KEY")
# 
# head(t_tricolor, 4)

## ----echo=FALSE-----------------------------------------------------------------------------------

subset(vignette_metadata$t_tricolor, 
       select = suwo:::.format_query_output(only_basic_columns = TRUE))

## ----eval = FALSE---------------------------------------------------------------------------------
# 
# # replace "YOUR_XC_API_KEY" with your key
# a_hahneli <- query_xenocanto(
#   species = 'sp:"Ameerega hahneli" cnt:"French Guiana" q:"A"',
#   api_key = "YOUR_XC_API_KEY")
# 
# head(a_hahneli, 4)

## ----echo=FALSE-----------------------------------------------------------------------------------

subset(vignette_metadata$a_hahneli,
       select = suwo:::.format_query_output(only_basic_columns = TRUE))

## -------------------------------------------------------------------------------------------------
# initial query
c_eisentrauti <- query_inaturalist(species = "Chorthippus eisentrauti")

head(c_eisentrauti, 4)

# exclude new observations (simulate old data)
old_c_eisentrauti <- 
  c_eisentrauti[c_eisentrauti$date <= "2024-12-31" | is.na(c_eisentrauti$date), 
                ]

# update "old" data
upd_c_eisentrauti <- update_metadata(metadata = old_c_eisentrauti)

# compare number of records
nrow(old_c_eisentrauti) == nrow(upd_c_eisentrauti)


## ----eval = FALSE---------------------------------------------------------------------------------
# 
# truf_xc <- query_xenocanto(species = "Turdus rufiventris",
#                              format = "sound",
#                              api_key = "YOUR_XC_API_KEY")
# truf_gbf <- query_gbif(species = "Turdus rufiventris", format = "sound")
# truf_ml <- query_macaulay(species = "Turdus rufiventris",
#                           format = "sound",
#                           path = tempdir())
# 
# # merge metadata
# merged_metadata <- merge_metadata(truf_xc, truf_gbf, truf_ml)
# 
# head(merged_metadata, 4)

## ----echo=FALSE-----------------------------------------------------------------------------------

merged_metadata <- suwo:::merged_metadata

head(merged_metadata, 4)


## ----eval = FALSE---------------------------------------------------------------------------------
# 
# options(species = "Turdus rufiventris", format = "sound")
# truf_xc <- query_xenocanto(api_key = "YOUR_XC_API_KEY")
# truf_gbf <- query_gbif()
# truf_ml <- query_macaulay(path = tempdir())
# 
# # merge metadata
# merged_metadata <- merge_metadata(truf_xc, truf_gbf, truf_ml)
# 

## ----eval = TRUE----------------------------------------------------------------------------------
# find duplicates
dups_merged_metadata <- find_duplicates(merged_metadata)

# look first 6 columns
head(dups_merged_metadata)

## ----echo=FALSE-----------------------------------------------------------------------------------

boesman_group <- 
  dups_merged_metadata$duplicate_group[dups_merged_metadata$key== 273100]

# Define display function
display_code <- function(value) {
  paste0("subset(dups_merged_metadata, duplicate_group == ", value, ")")
    }

## ----code = display_code(boesman_group)-----------------------------------------------------------
subset(dups_merged_metadata, duplicate_group == 75)

## -------------------------------------------------------------------------------------------------
# remove duplicates
dedup_metadata <- remove_duplicates(dups_merged_metadata)

## -------------------------------------------------------------------------------------------------
# look at first 4 columns of deduplicated metadata
head(dedup_metadata, 4)

## ----eval = TRUE----------------------------------------------------------------------------------

# query GBIF for Amanita zambiana images
a_zam <- query_gbif(species = "Amanita zambiana", format = "image")

# create folder for images
out_folder <- file.path(tempdir(), "amanita_zambiana")
dir.create(out_folder)

# download media files to a temporary directory
azam_files <- download_media(metadata = a_zam, path = out_folder)


## ----eval = TRUE----------------------------------------------------------------------------------

head(azam_files, 4)


## ----eval = FALSE---------------------------------------------------------------------------------
# 
# fs::dir_tree(path = out_folder)
# 

## ----echo=FALSE-----------------------------------------------------------------------------------

dir_tree(path = out_folder)


## -------------------------------------------------------------------------------------------------
# create a 6 pannel plot of the downloaded images
par(mfrow = c(2, 3), mar = c(1, 1, 2, 1))

for (i in 1:6) {
img <- jpeg::readJPEG(file.path(out_folder, azam_files$downloaded_file_name[i]))
  plot(
    1:2,
    type = 'n',
    axes = FALSE
  )
  rasterImage(img, 1, 1, 2, 2)
  title(main = paste(
    azam_files$country[i],
    azam_files$date[i],
    sep = "\n"
  ))
}


## ----echo=FALSE-----------------------------------------------------------------------------------
unlink(out_folder, recursive = TRUE)

## ----eval = FALSE---------------------------------------------------------------------------------
# 
# # query GBIF for longspined porcupinefish images
# d_holocanthus <- query_gbif(species = "Diodon holocanthus", format = "image")
# 
# # keep only JPEG records (for simplicity for this vignette)
# d_holocanthus <- d_holocanthus[d_holocanthus$file_extension == "jpeg", ]
# 
# # select 6 random JPEG records
# set.seed(666)
# d_holocanthus <- d_holocanthus[sample(seq_len(nrow(d_holocanthus)), 6),]
# 
# # create folder for images
# out_folder <- file.path(tempdir(), "diodon_holocanthus")
# dir.create(out_folder)
# 
# # download media files creating sub-directories by country
# dhol_files <- download_media(metadata = d_holocanthus,
#                              path = out_folder,
#                              folder_by = "country")
# 

## ----echo = FALSE---------------------------------------------------------------------------------

d_holocanthus <- vignette_metadata$d_holocanthus

# create folder for images
out_folder <- file.path(tempdir(), "diodon_holocanthus")
dir.create(out_folder)

# download media files creating sub-directories by country
dhol_files <- download_media(metadata = d_holocanthus,
                             path = out_folder,
                             folder_by = "country")

## ----eval=FALSE-----------------------------------------------------------------------------------
# 
# fs::dir_tree(path = out_folder)
# 

## ----echo=FALSE-----------------------------------------------------------------------------------

dir_tree(path = out_folder)


## -------------------------------------------------------------------------------------------------

dhol_files$downloaded_file_name


## -------------------------------------------------------------------------------------------------
# create a 6 pannel plot of the downloaded images
par(mfrow = c(2, 3), mar = c(1, 1, 2, 1))

for (i in 1:6) {
img <- jpeg::readJPEG(file.path(out_folder, dhol_files$downloaded_file_name[i]))
  plot(
    1:2,
    type = 'n',
    axes = FALSE
  )
  rasterImage(img, 1, 1, 2, 2)
  title(main = paste(
    substr(dhol_files$country[i], start = 1, stop = 14),
    dhol_files$date[i],
    sep = "\n"
  ))
}


## ----echo=FALSE-----------------------------------------------------------------------------------
unlink(out_folder, recursive = TRUE)

## ----session info---------------------------------------------------------------------------------
sessionInfo()


